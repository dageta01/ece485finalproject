/*----------------------------------------------------------------------------
 *      RL-ARM - RTX
 *----------------------------------------------------------------------------
 *      Name:    BLinky.c
 *      Purpose: RTX example program
 *----------------------------------------------------------------------------
 *      This code is part of the RealView Run-Time Library.
 *      Copyright (c) 2004-2014 KEIL - An ARM Company. All rights reserved.
 *---------------------------------------------------------------------------*/

#include "cmsis_os.h"
#include "LPC17xx.h"
#include "Board_LED.h"
#include "ADC.h"
#include "GLCD.h"

//#define MAIL_DISABLE
osThreadId tid_ADC_get;                  /* Thread id of task: phase_a */
osThreadId tid_ADC_LCD;                  /* Thread id of task: phase_b */
osThreadId tid_Task_Init;                  /* Thread id of task: Task_Init */
osThreadId tid_MAIL_country;
osThreadId tid_MAIL_print;


typedef struct{
	uint16_t adcVal;
	uint32_t tick;
} MSG;

osPoolDef(mpool, 16, MSG);
osPoolId(mpool);
osMessageQDef(ADC_msg, 16, &MSG);
osMessageQId(ADC_msg);


#ifndef MAIL_DISABLE
typedef struct{
	uint8_t number[2];
	uint8_t name[11];
	uint8_t capital[11];
}COUNTRY;

osMailQDef(mail, 16, COUNTRY);
osMailQId(mail);
#endif



osMutexDef(mutexLCD);
osMutexId(mutexLCD);

extern uint16_t AD_last;
extern uint8_t AD_done;

void Hex32ToBCD(uint32_t Hex, uint8_t *Dec)
  {
  uint32_t index = 9;
	Dec[10]=0;
	while(Hex>=10)
	{
		Dec[index--] = Hex%10 + '0';
		Hex /= 10;
	}	
	Dec[index]=Hex+'0';
}

/*----------------------------------------------------------------------------
 *      Thread 1
 *---------------------------------------------------------------------------*/
void ADC_get (void const *argument) {
	MSG* message;

	for(;;){
		message = osPoolAlloc(mpool);
		ADC_StartCnv();
		message->adcVal = ADC_GetCnv();
		message->tick = osKernelSysTick();
		osMessagePut(ADC_msg, (uint32_t) message, osWaitForever);
		osDelay(500);
	}
}
/*----------------------------------------------------------------------------
 *      Thread 2 
 *---------------------------------------------------------------------------*/
void ADC_LCD (void const *argument) {
	MSG* recMessage;
	osEvent evt;
	uint8_t i = 0;
	uint16_t ad_val;
	uint32_t tick;
	uint8_t ad_BCD[] = "0000000000";
	uint8_t tick_BCD[] = "0000000000";
	
	for(;;)
	{

		evt = osMessageGet(ADC_msg, osWaitForever);
		if(evt.status == osEventMessage)
		{
			osMutexWait(mutexLCD, osWaitForever);		
			recMessage = evt.value.p;
			ad_val = recMessage->adcVal;
			tick = recMessage->tick;
			Hex32ToBCD(ad_val, ad_BCD);
			Hex32ToBCD(tick, tick_BCD);
			GLCD_DisplayString(0,7,1, ad_BCD);
			GLCD_DisplayString(1,7,1,tick_BCD);
			osPoolFree(mpool, recMessage);
			osMutexRelease(mutexLCD);
		}


	}
}
osThreadDef(ADC_get, osPriorityNormal, 1, 0);
osThreadDef(ADC_LCD, osPriorityNormal, 1, 0);


#ifndef MAIL_DISABLE
/*----------------------------------------------------------------------------
 *      Thread 3 
 *---------------------------------------------------------------------------*/
void MAIL_country(void const *argument)
{
	COUNTRY *cPtr;
	static uint8_t i = 0;
	const COUNTRY china = {"1\0","China     \0","Beijing   \0"};
	const COUNTRY usa = {"2\0","USA       \0","Washington\0"};
	const COUNTRY france = {"3\0","France    \0","Paris     \0"};
	const COUNTRY england = {"4\0","England   \0","London    \0"};
	const COUNTRY japan = {"5\0","Japan     \0","Tokyo     \0"};
	COUNTRY countryArray[5];
	countryArray[0] = china;
	countryArray[1] = usa;
	countryArray[2] = france;
	countryArray[3] = england;
	countryArray[4] = japan;
	cPtr = osMailAlloc(mail,osWaitForever);
	for(;;)
	{
		if(i > 4)
		{
			i = 0;
		}

		cPtr = (countryArray + i);
		osMailPut(mail,cPtr);
		i++;
		osDelay(1100);
	}
}

/*----------------------------------------------------------------------------
 *      Thread 4 
 *---------------------------------------------------------------------------*/
void MAIL_print(void const *argument)
{
	COUNTRY *cPtr;
	osEvent evt;

	for(;;)
	{
		
		evt = osMailGet(mail, osWaitForever);
		if(evt.status == osEventMail)
		{
			osMutexWait(mutexLCD,osWaitForever);
			cPtr = evt.value.p;
			GLCD_DisplayString(3,9,1,cPtr->number);
			GLCD_DisplayString(4,9,1, cPtr->name);
			GLCD_DisplayString(5,9,1, cPtr->capital);
			osMailFree(mail, cPtr);
			osMutexRelease(mutexLCD);
		}

	}
}

osThreadDef(MAIL_country, osPriorityNormal, 1, 0);
osThreadDef(MAIL_print, osPriorityNormal, 1, 0);
#endif

void Task_Init (void const *argument) {
  for (;;) {

	tid_ADC_get = osThreadCreate(osThread(ADC_get), NULL);
	tid_ADC_LCD = osThreadCreate(osThread(ADC_LCD), NULL);
	mpool = osPoolCreate(osPool(mpool));
	ADC_msg = osMessageCreate(osMessageQ(ADC_msg), NULL);

	#ifndef MAIL_DISABLE
	tid_MAIL_country = osThreadCreate(osThread(MAIL_country),NULL);
	tid_MAIL_print = osThreadCreate(osThread(MAIL_print),NULL);
	mail = osMailCreate(osMailQ(mail), NULL);
	#endif
	mutexLCD = osMutexCreate(osMutex(mutexLCD));
	GLCD_DisplayString(0, 0, 1, "                               ");
	GLCD_DisplayString(1, 0, 1, "                               ");
	GLCD_DisplayString(3, 0, 1, "                               ");
	GLCD_DisplayString(4, 0, 1, "                               ");
	GLCD_DisplayString(5, 0, 1, "                               ");
		
		
	GLCD_DisplayString(0,0,1,"  AD:");
	GLCD_DisplayString(1,0,1,"TIME:");
		
	GLCD_DisplayString(3,0,1,"     No:");
	GLCD_DisplayString(4,0,1,"COUNTRY:");
	GLCD_DisplayString(5,0,1,"CAPITAL:");

	osThreadTerminate(tid_Task_Init);
}
}

osThreadDef(Task_Init, osPriorityNormal, 1, 0);


/*----------------------------------------------------------------------------
 *      Main: Initialize and start RTX Kernel
 *---------------------------------------------------------------------------*/
int main (void) {
//	osMutexId mutex_id;
  LED_Initialize();                         /* Initialize the LEDs           */
	ADC_Init();
	GLCD_Init();
	GLCD_Clear(White);
	GLCD_SetBackColor(Blue);
	GLCD_SetTextColor(White);
	
// tid_LEDB_On = osThreadCreate(osThread(LEDB_On), NULL);
// tid_LEDB_Off = osThreadCreate(osThread(LEDB_Off), NULL);
	

	tid_Task_Init = osThreadCreate(osThread(Task_Init), NULL);
	

	
  osDelay(osWaitForever);
  while(1);
}
